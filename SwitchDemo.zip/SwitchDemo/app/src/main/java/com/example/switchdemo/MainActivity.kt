package com.example.switchdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Switch
import android.widget.TextView
import android.widget.Button
import android.widget.ImageView
import android.widget.EditText
import android.content.Context
import android.view.View
import android.view.inputmethod.InputMethodManager




class MainActivity : AppCompatActivity() {

    private lateinit var xcodeSwitch: Switch
    private lateinit var languageSwitch: Switch
    private lateinit var kotlinSwitch: Switch
    private lateinit var textView: TextView
    private lateinit var imageView: ImageView
    private lateinit var nameEditText: EditText
    private lateinit var view: View


    var xcode: Int = 1
    var lang: Int = 0
    var kotlin: Int = 0
    var total: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        xcodeSwitch = findViewById(R.id.xcodeSwitch)
        languageSwitch = findViewById(R.id.languageSwitch)
        kotlinSwitch = findViewById(R.id.kotlinSwitch)
        textView = findViewById(R.id.myTextView)
        imageView = findViewById(R.id.myImageView)
        nameEditText = findViewById(R.id.nameEditText)


        // Set the initial text for the TextView
        textView.text = "Your Result"


        // Set the OnCheckedChangeListener for the Switch
        xcodeSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                xcode = 0



            } else {
                xcode = 1



            }
        }

        languageSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                lang = 1



            } else {
                lang = 0



            }
        }

        kotlinSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                kotlin = 1

                //textView.text = "$taco"


            } else {
                kotlin = 0
                //textView.text = "$taco"


            }
        }


        val submitButton = findViewById<Button>(R.id.submitButton)

        // to resign keyboard
        val inputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager


        submitButton.setOnClickListener {


            total = xcode + lang + kotlin
            val name = nameEditText.text.toString() // Get name from EditText
            //resigns keybaord on button click
            inputMethodManager.hideSoftInputFromWindow(nameEditText.windowToken, 0)
            if (total <= 1) {
                textView.text = "$total . $name, I don't think you studied. Try again."

                imageView.setImageResource(R.drawable.fail_image)
            }
            else if (total == 2) {
                textView.text = "$total . $name, almost there. Try again."
                imageView.setImageResource(R.drawable.fail_image)
            }
            else {
                textView.text = "Great job, $name. You got all three."
                imageView.setImageResource(R.drawable.success_image)
            }


        }


    }
}